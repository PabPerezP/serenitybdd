package gmail.ui;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;

@DefaultUrl("https://mail.google.com/")
public class GmailHomePage extends PageObject {
}